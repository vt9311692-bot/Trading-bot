#!/usr/bin/env python3
"""
cli.py — Command-line interface for the Binance Futures Trading Bot.

Usage examples
--------------
# Mock mode (no API keys needed):
python cli.py --symbol BTCUSDT --side BUY  --type MARKET --quantity 0.01
python cli.py --symbol ETHUSDT --side SELL --type LIMIT  --quantity 0.5 --price 3400
python cli.py --symbol SOLUSDT --side BUY  --type STOP_MARKET --quantity 1 --stop-price 160

# Live testnet mode:
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001 \\
              --api-key YOUR_KEY --api-secret YOUR_SECRET --live
"""

import argparse
import sys
import os

# Allow running from project root without installing the package
sys.path.insert(0, os.path.dirname(__file__))

from bot.logging_config import setup_logging
from bot.client import BinanceFuturesClient
from bot.validators import validate_all, ValidationError
from bot.orders import place_order, format_order_summary, format_order_response

import logging

logger = logging.getLogger("trading_bot.cli")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Trading Bot — Mock & Live Testnet",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # MARKET BUY (mock, no keys needed)
  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

  # LIMIT SELL (mock)
  python cli.py --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.5 --price 3400

  # STOP_MARKET (mock)
  python cli.py --symbol SOLUSDT --side BUY --type STOP_MARKET --quantity 1 --stop-price 160

  # Live testnet
  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001 \\
                --api-key <KEY> --api-secret <SECRET> --live
        """,
    )

    # ── Order parameters ──────────────────────────────────────────────
    parser.add_argument("--symbol",     required=True,  help="Trading pair  e.g. BTCUSDT")
    parser.add_argument("--side",       required=True,  help="BUY or SELL")
    parser.add_argument("--type",       required=True,  dest="order_type",
                        help="MARKET | LIMIT | STOP_MARKET")
    parser.add_argument("--quantity",   required=True,  help="Order quantity (e.g. 0.01)")
    parser.add_argument("--price",      default=None,   help="Limit price (required for LIMIT)")
    parser.add_argument("--stop-price", default=None,   dest="stop_price",
                        help="Stop trigger price (required for STOP_MARKET)")

    # ── Connection / mode ─────────────────────────────────────────────
    parser.add_argument("--api-key",    default="",     dest="api_key",
                        help="Binance API key (only needed with --live)")
    parser.add_argument("--api-secret", default="",     dest="api_secret",
                        help="Binance API secret (only needed with --live)")
    parser.add_argument("--live",       action="store_true", default=False,
                        help="Use real Binance Futures Testnet (default: mock mode)")
    parser.add_argument("--log-dir",    default="logs", dest="log_dir",
                        help="Directory for log files (default: logs/)")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # ── Logging ───────────────────────────────────────────────────────
    setup_logging(log_dir=args.log_dir)
    mode = "LIVE" if args.live else "MOCK"
    logger.info("=== Trading Bot started | mode=%s ===", mode)

    # ── Validate inputs ───────────────────────────────────────────────
    try:
        params = validate_all(
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
            stop_price=args.stop_price,
        )
    except ValidationError as e:
        logger.error("Validation error: %s", e)
        print(f"\n❌  Validation error: {e}\n")
        sys.exit(1)

    # ── Print request summary ─────────────────────────────────────────
    print()
    print(format_order_summary(params))

    # ── Build client ──────────────────────────────────────────────────
    if args.live and not (args.api_key and args.api_secret):
        print("❌  --live mode requires --api-key and --api-secret.\n")
        logger.error("Live mode requested but API credentials missing.")
        sys.exit(1)

    client = BinanceFuturesClient(
        api_key=args.api_key,
        api_secret=args.api_secret,
        mock=not args.live,
    )

    # ── Fetch & show current price ────────────────────────────────────
    try:
        mark_price = client.get_price(params["symbol"])
        print(f"  Current mark price for {params['symbol']}: {mark_price}")
    except Exception as e:
        logger.warning("Could not fetch mark price: %s", e)

    # ── Place order ───────────────────────────────────────────────────
    try:
        response = place_order(
            client=client,
            symbol=params["symbol"],
            side=params["side"],
            order_type=params["order_type"],
            quantity=params["quantity"],
            price=params["price"],
            stop_price=params["stop_price"],
        )
    except RuntimeError as e:
        logger.error("Order failed: %s", e)
        print(f"\n❌  {e}\n")
        sys.exit(1)

    # ── Print response ────────────────────────────────────────────────
    print()
    print(format_order_response(response))
    print()
    print(f"✅  Order submitted successfully! Order ID: {response['orderId']}")
    print()

    logger.info("=== Trading Bot finished ===")


if __name__ == "__main__":
    main()
