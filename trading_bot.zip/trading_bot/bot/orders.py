"""
orders.py — Order placement logic and result formatting.
"""

import logging
from bot.client import BinanceFuturesClient

logger = logging.getLogger("trading_bot.orders")


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: float | None = None,
    stop_price: float | None = None,
) -> dict:
    """
    Place an order via *client* and return the raw response dict.
    Raises RuntimeError wrapping any API / network exception.
    """
    logger.info(
        "Placing order | symbol=%s side=%s type=%s qty=%s price=%s stop_price=%s",
        symbol, side, order_type, quantity, price, stop_price,
    )
    try:
        response = client.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price,
        )
    except Exception as exc:
        logger.error("Order placement failed | %s: %s", type(exc).__name__, exc)
        raise RuntimeError(f"Order placement failed: {exc}") from exc

    logger.info("Order accepted | orderId=%s status=%s", response.get("orderId"), response.get("status"))
    return response


def format_order_summary(params: dict) -> str:
    """Human-readable summary of the order *request*."""
    lines = [
        "┌─ Order Request ─────────────────────────────",
        f"│  Symbol     : {params['symbol']}",
        f"│  Side       : {params['side']}",
        f"│  Type       : {params['order_type']}",
        f"│  Quantity   : {params['quantity']}",
    ]
    if params.get("price"):
        lines.append(f"│  Price      : {params['price']}")
    if params.get("stop_price"):
        lines.append(f"│  Stop Price : {params['stop_price']}")
    lines.append("└─────────────────────────────────────────────")
    return "\n".join(lines)


def format_order_response(response: dict) -> str:
    """Human-readable summary of the order *response*."""
    mock_tag = "  ⚙  [MOCK — simulated response]" if response.get("_mock") else ""
    lines = [
        "┌─ Order Response ────────────────────────────" + mock_tag,
        f"│  Order ID   : {response.get('orderId')}",
        f"│  Symbol     : {response.get('symbol')}",
        f"│  Side       : {response.get('side')}",
        f"│  Type       : {response.get('type')}",
        f"│  Status     : {response.get('status')}",
        f"│  Orig Qty   : {response.get('origQty')}",
        f"│  Exec Qty   : {response.get('executedQty')}",
        f"│  Avg Price  : {response.get('avgPrice')}",
    ]
    if response.get("stopPrice") and response["stopPrice"] != "0":
        lines.append(f"│  Stop Price : {response['stopPrice']}")
    lines.append("└─────────────────────────────────────────────")
    return "\n".join(lines)
