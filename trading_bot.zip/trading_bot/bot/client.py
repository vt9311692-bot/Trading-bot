"""
client.py — Binance Futures client wrapper.

Supports two modes:
  - mock   : simulates Binance Futures Testnet responses locally (no account needed)
  - live   : hits the real Binance Futures Testnet at https://testnet.binancefuture.com
"""

import time
import random
import hashlib
import hmac
import logging
from urllib.parse import urlencode

logger = logging.getLogger("trading_bot.client")

# ---------------------------------------------------------------------------
# Mock price table (simulated mid-prices for common symbols)
# ---------------------------------------------------------------------------
MOCK_PRICES = {
    "BTCUSDT":  67_432.50,
    "ETHUSDT":   3_512.80,
    "BNBUSDT":     598.40,
    "SOLUSDT":     172.30,
    "XRPUSDT":       0.5423,
    "DOGEUSDT":      0.1612,
}

_mock_order_id = int(time.time() * 1000)


def _next_order_id() -> int:
    global _mock_order_id
    _mock_order_id += random.randint(1, 99)
    return _mock_order_id


class BinanceFuturesClient:
    """
    Thin wrapper around the Binance Futures Testnet REST API.
    When *mock=True* every API call is answered locally — useful when you
    cannot create a testnet account.
    """

    BASE_URL = "https://testnet.binancefuture.com"

    def __init__(self, api_key: str = "", api_secret: str = "", mock: bool = True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.mock = mock
        logger.info(
            "BinanceFuturesClient initialised | mode=%s",
            "MOCK" if mock else "LIVE",
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sign(self, params: dict) -> str:
        query = urlencode(params)
        return hmac.new(
            self.api_secret.encode(), query.encode(), hashlib.sha256
        ).hexdigest()

    def _headers(self) -> dict:
        return {"X-MBX-APIKEY": self.api_key, "Content-Type": "application/x-www-form-urlencoded"}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_price(self, symbol: str) -> float:
        """Return current mark price for *symbol*."""
        if self.mock:
            price = self._mock_get_price(symbol)
        else:
            price = self._live_get_price(symbol)
        logger.info("get_price | symbol=%s price=%s", symbol, price)
        return price

    def place_order(self, symbol: str, side: str, order_type: str,
                    quantity: float, price: float | None = None,
                    stop_price: float | None = None) -> dict:
        """Place a new futures order and return the exchange response dict."""
        logger.info(
            "place_order | symbol=%s side=%s type=%s qty=%s price=%s stop_price=%s",
            symbol, side, order_type, quantity, price, stop_price,
        )
        if self.mock:
            response = self._mock_place_order(symbol, side, order_type, quantity, price, stop_price)
        else:
            response = self._live_place_order(symbol, side, order_type, quantity, price, stop_price)

        logger.info("place_order response | %s", response)
        return response

    # ------------------------------------------------------------------
    # Mock implementations
    # ------------------------------------------------------------------

    def _mock_get_price(self, symbol: str) -> float:
        sym = symbol.upper()
        if sym not in MOCK_PRICES:
            raise ValueError(f"Symbol '{sym}' is not supported in mock mode. "
                             f"Supported: {', '.join(MOCK_PRICES)}")
        # Add ±0.05 % jitter so each call looks realistic
        base = MOCK_PRICES[sym]
        jitter = base * random.uniform(-0.0005, 0.0005)
        return round(base + jitter, 8)

    def _mock_place_order(self, symbol: str, side: str, order_type: str,
                          quantity: float, price: float | None,
                          stop_price: float | None) -> dict:
        sym = symbol.upper()
        mark_price = self._mock_get_price(sym)
        order_id = _next_order_id()
        ts = int(time.time() * 1000)

        if order_type == "MARKET":
            # Market orders fill immediately at mark price
            avg_price = mark_price
            status = "FILLED"
            executed_qty = quantity
        elif order_type == "LIMIT":
            avg_price = price
            # Simulate partial / open depending on price vs market
            if side == "BUY" and price >= mark_price:
                status, executed_qty = "FILLED", quantity
            elif side == "SELL" and price <= mark_price:
                status, executed_qty = "FILLED", quantity
            else:
                status, executed_qty = "NEW", 0.0
        elif order_type == "STOP_MARKET":
            avg_price = stop_price
            status, executed_qty = "NEW", 0.0
        else:
            avg_price = price or mark_price
            status, executed_qty = "NEW", 0.0

        return {
            "orderId": order_id,
            "symbol": sym,
            "status": status,
            "clientOrderId": f"mock_{order_id}",
            "price": str(price or "0"),
            "avgPrice": str(round(avg_price, 8)) if avg_price else "0",
            "origQty": str(quantity),
            "executedQty": str(executed_qty),
            "type": order_type,
            "side": side,
            "stopPrice": str(stop_price or "0"),
            "timeInForce": "GTC",
            "updateTime": ts,
            "time": ts,
            "_mock": True,
        }

    # ------------------------------------------------------------------
    # Live (real testnet) implementations
    # ------------------------------------------------------------------

    def _live_get_price(self, symbol: str) -> float:
        try:
            import requests
        except ImportError:
            raise RuntimeError("'requests' package is required for live mode. pip install requests")
        url = f"{self.BASE_URL}/fapi/v1/ticker/price"
        r = requests.get(url, params={"symbol": symbol.upper()}, timeout=10)
        r.raise_for_status()
        return float(r.json()["price"])

    def _live_place_order(self, symbol: str, side: str, order_type: str,
                          quantity: float, price: float | None,
                          stop_price: float | None) -> dict:
        try:
            import requests
        except ImportError:
            raise RuntimeError("'requests' package is required for live mode.")

        params: dict = {
            "symbol": symbol.upper(),
            "side": side,
            "type": order_type,
            "quantity": quantity,
            "timestamp": int(time.time() * 1000),
        }
        if order_type == "LIMIT":
            params["price"] = price
            params["timeInForce"] = "GTC"
        if stop_price is not None:
            params["stopPrice"] = stop_price

        params["signature"] = self._sign(params)
        url = f"{self.BASE_URL}/fapi/v1/order"
        logger.debug("POST %s params=%s", url, {k: v for k, v in params.items() if k != "signature"})
        r = requests.post(url, headers=self._headers(), data=params, timeout=10)
        try:
            r.raise_for_status()
        except Exception:
            logger.error("API error: %s %s", r.status_code, r.text)
            raise
        return r.json()
