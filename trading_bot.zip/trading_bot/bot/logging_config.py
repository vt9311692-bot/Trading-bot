"""
logging_config.py — Structured logging setup.
Logs go to both the console (INFO+) and a rotating log file (DEBUG+).
"""

import logging
import logging.handlers
import os
from pathlib import Path


def setup_logging(log_dir: str = "logs", log_file: str = "trading_bot.log") -> None:
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    log_path = os.path.join(log_dir, log_file)

    root = logging.getLogger("trading_bot")
    root.setLevel(logging.DEBUG)

    # ── File handler (DEBUG, rotating 5 MB × 3 backups) ──────────────────
    fh = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )

    # ── Console handler (INFO) ────────────────────────────────────────────
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter("%(levelname)-8s %(message)s"))

    root.addHandler(fh)
    root.addHandler(ch)
    logging.getLogger("trading_bot").info("Logging initialised | file=%s", log_path)
