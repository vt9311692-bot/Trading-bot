"""
validators.py — Input validation for order parameters.
"""

import re
import logging

logger = logging.getLogger("trading_bot.validators")

VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET"}
SYMBOL_RE = re.compile(r"^[A-Z]{3,12}USDT$")


class ValidationError(ValueError):
    """Raised when user-supplied parameters fail validation."""


def validate_symbol(symbol: str) -> str:
    sym = symbol.strip().upper()
    if not SYMBOL_RE.match(sym):
        raise ValidationError(
            f"Invalid symbol '{sym}'. Expected format: <BASE>USDT  e.g. BTCUSDT"
        )
    logger.debug("validate_symbol OK | %s", sym)
    return sym


def validate_side(side: str) -> str:
    s = side.strip().upper()
    if s not in VALID_SIDES:
        raise ValidationError(
            f"Invalid side '{s}'. Must be one of: {', '.join(sorted(VALID_SIDES))}"
        )
    logger.debug("validate_side OK | %s", s)
    return s


def validate_order_type(order_type: str) -> str:
    ot = order_type.strip().upper()
    if ot not in VALID_ORDER_TYPES:
        raise ValidationError(
            f"Invalid order type '{ot}'. Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}"
        )
    logger.debug("validate_order_type OK | %s", ot)
    return ot


def validate_quantity(quantity: str) -> float:
    try:
        qty = float(quantity)
    except (TypeError, ValueError):
        raise ValidationError(f"Invalid quantity '{quantity}'. Must be a positive number.")
    if qty <= 0:
        raise ValidationError(f"Quantity must be > 0, got {qty}.")
    logger.debug("validate_quantity OK | %s", qty)
    return qty


def validate_price(price: str | None, required: bool = False) -> float | None:
    if price is None or price == "":
        if required:
            raise ValidationError("Price is required for LIMIT and STOP_MARKET orders.")
        return None
    try:
        p = float(price)
    except (TypeError, ValueError):
        raise ValidationError(f"Invalid price '{price}'. Must be a positive number.")
    if p <= 0:
        raise ValidationError(f"Price must be > 0, got {p}.")
    logger.debug("validate_price OK | %s", p)
    return p


def validate_all(symbol: str, side: str, order_type: str,
                 quantity: str, price: str | None = None,
                 stop_price: str | None = None) -> dict:
    """
    Validate all order fields and return a cleaned dict.
    Raises ValidationError on the first failure.
    """
    sym = validate_symbol(symbol)
    s = validate_side(side)
    ot = validate_order_type(order_type)
    qty = validate_quantity(quantity)
    p = validate_price(price, required=(ot == "LIMIT"))
    sp = validate_price(stop_price, required=(ot == "STOP_MARKET"))

    return {
        "symbol": sym,
        "side": s,
        "order_type": ot,
        "quantity": qty,
        "price": p,
        "stop_price": sp,
    }
